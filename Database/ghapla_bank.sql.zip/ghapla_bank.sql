-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2018 at 12:03 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ghapla_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_branch_ifsc`
--

CREATE TABLE `bank_branch_ifsc` (
  `ifsc` varchar(20) NOT NULL,
  `bank_branch` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_branch_ifsc`
--

INSERT INTO `bank_branch_ifsc` (`ifsc`, `bank_branch`) VALUES
('ABIN0000AB', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078'),
('SBIN0000AB', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018');

-- --------------------------------------------------------

--
-- Table structure for table `beneficiary`
--

CREATE TABLE `beneficiary` (
  `customer_account_number` varchar(50) NOT NULL,
  `beneficiary_account_number` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `ifsc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beneficiary`
--

INSERT INTO `beneficiary` (`customer_account_number`, `beneficiary_account_number`, `username`, `nickname`, `ifsc`) VALUES
('0987654321', '1234567890', 'Utkarsh Gupta', 'Ballu', 'ABIN0000AB'),
('1234567890', '0987654321', 'Shubham Bengani', 'Ben', 'SBIN0000AB'),
('654789321', '1234567890', 'Utkarsh Gupta', 'Ballu', 'ABIN0000AB');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(10) NOT NULL,
  `password` varchar(500) NOT NULL,
  `card_no` varchar(16) NOT NULL,
  `pin_no` int(4) NOT NULL,
  `username` varchar(30) NOT NULL,
  `aadhar_no` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_no` varchar(10) NOT NULL,
  `account_no` varchar(50) NOT NULL,
  `account_balance` float NOT NULL,
  `account_type` varchar(10) NOT NULL,
  `ifsc` varchar(20) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `password`, `card_no`, `pin_no`, `username`, `aadhar_no`, `email`, `phone_no`, `account_no`, `account_balance`, `account_type`, `ifsc`, `login_date`, `login_time`) VALUES
(12345, 'abcd', '4321432143214321', 4321, 'Shubham Bengani', '987687657654', 'shubhambengani22@gmail.com', '9148894717', '0987654321', 54360, 'Savings', 'SBIN0000AB', '2018-11-29', '14:54:19'),
(54321, '12345', '3456456756786789', 1010, 'Vrinda Agrawal', '101010101010', 'vrindaagrawal05@gmail.com', '147852369', '654789321', 174716, 'Savings', 'ABIN0000AB', '2018-11-26', '09:38:14'),
(858310490, '123456789', '1234234534564567', 1234, 'Utkarsh Gupta', '888888888888', '28utkarsh08@gmail.com', '9901598544', '1234567890', 40696, 'Savings', 'ABIN0000AB', '2018-12-03', '10:22:39');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `customer_account_number` varchar(50) NOT NULL,
  `beneficiary_account_number` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `transaction_details` varchar(200) NOT NULL,
  `amount` float NOT NULL,
  `balance_amount` int(11) NOT NULL,
  `dr_cr` varchar(10) NOT NULL,
  `pay_via` varchar(4) NOT NULL,
  `remarks` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `customer_account_number`, `beneficiary_account_number`, `date`, `transaction_details`, `amount`, `balance_amount`, `dr_cr`, `pay_via`, `remarks`) VALUES
(7, '0987654321', '1234567890', '2018-11-25', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 12541, 37874, 'DR', 'rtgs', 'Food'),
(8, '1234567890', '0987654321', '2018-11-25', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 12541, 77682, 'CR', 'rtgs', 'Food'),
(9, '0987654321', '654789321', '2018-11-27', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 30000, 7874, 'DR', 'imps', 'Jwellery'),
(10, '654789321', '0987654321', '2018-11-27', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 30000, 184216, 'CR', 'imps', 'Jwellery'),
(11, '1234567890', '0987654321', '2018-11-30', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 40000, 37682, 'DR', 'imps', 'Scooty'),
(12, '0987654321', '1234567890', '2018-11-30', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 40000, 47874, 'CR', 'imps', 'Scooty'),
(13, '1234567890', '0987654321', '2018-12-13', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 10000, 27682, 'DR', 'neft', 'Bed'),
(14, '0987654321', '1234567890', '2018-12-13', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 10000, 57874, 'CR', 'neft', 'Bed'),
(15, '1234567890', '654789321', '2018-12-12', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 25000, 2682, 'DR', 'neft', 'College Fee'),
(16, '654789321', '1234567890', '2018-12-12', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 25000, 209216, 'CR', 'neft', 'College Fee'),
(17, '654789321', '1234567890', '2018-12-19', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 100000, 109216, 'DR', 'rtgs', 'Return'),
(18, '1234567890', '654789321', '2018-12-19', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 100000, 102682, 'CR', 'rtgs', 'Return'),
(19, '1234567890', '0987654321', '2018-11-26', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 100000, 2682, 'DR', 'rtgs', 'Gifts'),
(20, '0987654321', '1234567890', '2018-11-26', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 100000, 157874, 'CR', 'rtgs', 'Gifts'),
(21, '0987654321', '1234567890', '2018-11-26', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 100000, 57874, 'DR', 'rtgs', 'Gifts'),
(22, '1234567890', '0987654321', '2018-11-26', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 100000, 102682, 'CR', 'rtgs', 'Gifts'),
(23, '1234567890', '654789321', '2018-11-28', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 65000, 37682, 'DR', 'neft', 'Travel'),
(24, '654789321', '1234567890', '2018-11-28', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 65000, 174216, 'CR', 'neft', 'Travel'),
(25, '1234567890', '0987654321', '2018-11-30', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 1000, 36682, 'DR', 'imps', 'Bill'),
(26, '0987654321', '1234567890', '2018-11-30', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 1000, 58874, 'CR', 'imps', 'Bill'),
(27, '0987654321', '1234567890', '2018-11-30', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 2514, 56360, 'DR', 'neft', 'Free'),
(28, '1234567890', '0987654321', '2018-11-30', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 2514, 39196, 'CR', 'neft', 'Free'),
(29, '0987654321', '1234567890', '2018-11-29', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 2000, 54360, 'DR', 'neft', 'Bill'),
(30, '1234567890', '0987654321', '2018-11-29', 'STATE BANK OF INDIA - CHAMARAJPET, BENGALURU, 560018', 2000, 41196, 'CR', 'neft', 'Bill'),
(31, '1234567890', '654789321', '2018-12-11', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 500, 40696, 'DR', 'neft', 'abc'),
(32, '654789321', '1234567890', '2018-12-11', 'ALLAHABAD BANK - J.P. NAGAR, 5TH PHASE, BENGALURU, 560078', 500, 174716, 'CR', 'neft', 'abc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_branch_ifsc`
--
ALTER TABLE `bank_branch_ifsc`
  ADD PRIMARY KEY (`ifsc`);

--
-- Indexes for table `beneficiary`
--
ALTER TABLE `beneficiary`
  ADD PRIMARY KEY (`customer_account_number`,`beneficiary_account_number`),
  ADD KEY `Beneficiary_Acc_Number` (`beneficiary_account_number`),
  ADD KEY `ifsc_2` (`ifsc`),
  ADD KEY `ifsc` (`ifsc`) USING BTREE;

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `card_no` (`card_no`),
  ADD UNIQUE KEY `aadhar_no` (`aadhar_no`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `account_no` (`account_no`),
  ADD KEY `IFSC_FOREIGN_CUSTOMER` (`ifsc`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `beneficiary`
--
ALTER TABLE `beneficiary`
  ADD CONSTRAINT `Beneficiary_Acc_Number` FOREIGN KEY (`beneficiary_account_number`) REFERENCES `customer` (`account_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Customer_Acc_Number` FOREIGN KEY (`customer_account_number`) REFERENCES `customer` (`account_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `IFSC_Foreign` FOREIGN KEY (`ifsc`) REFERENCES `bank_branch_ifsc` (`ifsc`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `IFSC_FOREIGN_CUSTOMER` FOREIGN KEY (`ifsc`) REFERENCES `bank_branch_ifsc` (`ifsc`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
